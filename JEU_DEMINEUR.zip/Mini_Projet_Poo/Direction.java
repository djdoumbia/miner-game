package poo.tp.premierspas;

    // Enumération des directions des cases voisines
     public enum Direction {
        Nord,
        Sud,
        Ouest,
        Est,
        NordOuest,
        NordEst,
        SudOuest,
        SudEst
    }