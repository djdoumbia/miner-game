
package poo.tp.premierspas;
import java.util.*;
import java.io.*;

public class Demineur{

   /**********************************************************************************************************
    * save                  methode(fonction) qui consiste à  sauvegarder l'état actuel de la grille         *
    *                       de jeu dans un fichier texte spécifié par le chemin d'accès "filePath".          *
    *                                                                                                        *
    * En entrée:            Elle prend deux paramétres                                                       *
    *                       "filePath": le chemin d'accès du fichier dans lequel la grille sera sauvegardée  *
    *                       "grille": la grille de jeu actuelle à sauvegarder                                *
    *                                                                                                        *                                                                                             *
    **********************************************************************************************************/
    private void save(String filePath, Grille grille){
        File file = new File(filePath);
        if(!file.exists()){
            try{
                file.createNewFile();
            } catch(IOException e){
                e.printStackTrace();
            }
        }
        else{
            try{
                FileWriter writer = new FileWriter(file);
                BufferedWriter  bw = new BufferedWriter(writer);
                bw.write("Nombre de lignes : " + grille.getNbLigne());
                bw.newLine();
                bw.write("Nombre de colonnes : " + grille.getNbColonne());
                bw.newLine();
                bw.write("Pourcentage de mines placées : " + grille.getPourcentageMinesPlacees());
                bw.newLine();
                for(int i = 0; i < grille.getNbLigne(); i++){
                    for(int j = 0; j < grille.getNbColonne(); j++){
                        if (!grille.getCase(i,j).estDecouverte() && !grille.getCase(i,j).estMarquee()){
                            bw.write( grille.getCase(i,j).getValeur() + "_c" + " ");// on ecrit dans chaque case son etat et sa valeur separé pae "_"; c = cachée
                        }
                        if (grille.getCase(i,j).estDecouverte()){
                            bw.write(grille.getCase(i,j).getValeur() + "_d" + " ");// d = decouverte
                        }

                        if (grille.getCase(i,j).estMarquee()){
                            bw.write(grille.getCase(i,j).getValeur() + "_m" + " "); // m = maequée
                        }
                    }
                    bw.write("\n");
                }
                bw.close();
                writer.close();
            } catch(IOException e){
                e.printStackTrace();
            }
        }
    }


   /**********************************************************************************************************
    * load                  methode(fonction) qui consiste à charger une grille de jeu à partir d'un         *
    *                       fichier texte.                                                                   *
    *                                                                                                        *                                                                                                      *
    * En entrée:            Elle prend un paramétres                                                         *
    *                       "filePath": le chemin d'accès au fichier texte contenant les informations de     *
    *                                   la grille, telles que la taille, le pourcentage de mines et l'état   *
    *                                   de chaque case (découverte, marquée ou cachée).                      *
    *                                                                                                        *
    * En sortie:            Elle retourne la grille de jeu correspondante.                                   *
    *                                                                                                        *                                                                                             *
    **********************************************************************************************************/
    private Grille load(String filePath){
        int nbLigne = 0, nbColonne = 0, nbMines = 0 ;
        String[][] etats = new String[nbLigne][nbColonne];
        Grille grille = new Grille(nbLigne, nbColonne, nbMines);
        File file = new File(filePath);
        if(!file.exists()){
            try{
                file.createNewFile();
            } catch(IOException e){
                e.printStackTrace();
            }
        }
        else{
            try{
                BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
                String line = "";
                while(line != null){
                    line = reader.readLine();
                    if (line != null && line.contains("Nombre de lignes")){
                        String[] lineSplit = line.split(":") ;
                        nbLigne = Integer.parseInt(lineSplit[1].trim()) ;
                    }

                    if (line != null && line.contains("Nombre de colonnes")){
                        String[] lineSplit = line.split(":") ;
                        nbColonne = Integer.parseInt(lineSplit[1].trim()) ;
                    }

                    if (line != null && line.contains("Pourcentage de mines placées")){
                        String[] lineSplit = line.split(":") ;
                        nbMines = Integer.parseInt(lineSplit[1].trim()) ;
                    }

                    grille = new Grille(nbLigne, nbColonne, nbMines) ;

                    grille.initialiseGrille();

                    if (
                            line != null &&
                            !line.contains("Nombre de lignes") &&
                            !line.contains("Nombre de colonnes") &&
                            !line.contains("Pourcentage de mines placées")
                    ) {
                        etats = new String[nbLigne][nbColonne] ;
                        for (int i = 0; i < nbLigne; i++) {
                            String[] lineSplit = line.split(" ");

                            for (int j = 0; j < nbColonne; j++) {
                                String[] elementSplit = lineSplit[j].split("_");
                                etats[i][j] = elementSplit[1].trim();

                                int valeur = Integer.parseInt(elementSplit[0].trim());

                                grille.getCase(i, j).setValeur(valeur);

                                if (valeur == -1){
                                    grille.getCase(i, j).setEstMine(true);
                                }
                            }
                            line = reader.readLine();
                        }
                        break;
                    }
                }
                reader.close();
            } catch(IOException e){
                e.printStackTrace();
            }
        }

        for(int i = 0; i < nbLigne; i++) {
            for (int j = 0; j < nbColonne; j++){
                switch (etats[i][j]){
                    case "d":
                        grille.getCase(i, j).setEstMarquee(false);
                        grille.getCase(i, j).uncover(true);
                        break;

                    case "m":
                        grille.getCase(i, j).setEstMarquee(true);
                        grille.getCase(i, j).setEstDecouverte(false);
                        break;

                    case "c":
                        grille.getCase(i, j).setEstMarquee(false);
                        grille.getCase(i, j).setEstDecouverte(false);
                        break;
                }
            }
        }
        return grille ;
    }

    private void menuInitialisation(){
        System.out.println("------------------------------------------------");
        System.out.println("| 1 - Recharger la dernière grille sauvegardée |");
        System.out.println("| 2 - Lancer une nouvelle grille               |");
        System.out.println("| 3 - Quitter le jeu                           |");
        System.out.println("------------------------------------------------");
    }

    private void menu(){
        System.out.print("\n");
        System.out.println("---------------------------------");
        System.out.println("| 1 - Decouvrir la case         |");
        System.out.println("| 2 - Marquer la case           |");
        System.out.println("| 3 - Sauvegarder la grille     |");
        System.out.println("| 4 - Quitter le jeu            |");
        System.out.println("---------------------------------");
    }

   /**********************************************************************************************************
    * jouer                  Fonction qui permet de jouer au jeu demineur, en créant une grille,de découvrir *
    *                        ou de marquer des cases en fonction des choix de l'utilisateur. Et aussi        *
    *                        sauvegarder la grille en cours de partie.                                       *
    *                                                                                                        *                                                                     *                                                                                             *
    **********************************************************************************************************/
    public void jouer(){
        Grille grille = new Grille(0, 0, 0);
        int nbLigne, nbColonne ;
        int i, j ;
        int nbMines ;
        int choixInitial, choix;
        Scanner scanner = new Scanner(System.in);
        menuInitialisation();
        System.out.print("Entrez votre choix \uD83D\uDC49 : ");
        choixInitial = scanner.nextInt();
        switch (choixInitial){
            case 1:
                System.out.println("\n**** Recharger la dernière grille sauvegardée ... \n");
                grille = load("save.txt");
                //grille.afficheGrille(true);
                grille.afficheGrille(false);
                break;

            case 2:
                System.out.println("\n**** Lancer une nouvelle grille ... \n");
                System.out.print("Entrez le nombre de lignes de la grille : ");
                nbLigne =  scanner.nextInt();
                System.out.print("Entrez le nombre de colonnes de la grille : ");
                nbColonne =  scanner.nextInt();
                System.out.print("Entrez le pourcentage de mines à placer : ");
                nbMines =  scanner.nextInt();
                grille = new Grille(nbLigne, nbColonne, nbMines);
                grille.initialiseGrille();
                grille.placeMine();
                //grille.afficheGrille(true);
                grille.afficheGrille(false);
                break;

            case 3:
                System.out.println("\n**** Quitter le jeu ... \n");
                System.exit(1);
        }

        while(true){
            menu() ;
            System.out.print("Entrez votre choix \uD83D\uDC49 : ");
            choix = scanner.nextInt();
            switch (choix){
                case 1:
                    System.out.println("\n**** Decouvrir la case ... \n");
                    System.out.print("Entrez la coordonnée i de la case : ");
                    i =  scanner.nextInt();
                    System.out.print("Entrez la coordonnée j de la case : ");
                    j =  scanner.nextInt();

                    if (
                        !grille.getCase(i, j).estMinee() &&
                        !grille.getCase(i, j).estDecouverte() &&
                        !grille.getCase(i, j).estMarquee()
                    ) {
                        grille.getCase(i, j).uncover(false);
                    }

                    if (
                         grille.getCase(i, j).estDecouverte() || grille.getCase(i, j).estMarquee()
                    ) {
                        System.out.println("!!! On ne peut pas découvrir une case découverte ou marquée !!!");
                    }

                    if(
                        !grille.getCase(i, j).estMarquee() &&
                        !grille.getCase(i, j).estDecouverte() &&
                         grille.getCase(i, j).estMinee()
                    ){
                        System.out.println("\n****** BOOOOOM Game over ******* ");
                        grille.afficheGrille(true);
                        System.exit(1);
                    }

                    break;

                case 2:
                    System.out.println("\n**** Marquer la case ... \n");
                    System.out.print("Entrez la coordonnée i de la case : ");
                    i =  scanner.nextInt();
                    System.out.print("Entrez la coordonnée j de la case : ");
                    j =  scanner.nextInt();
                    grille.getCase(i, j).marquerCase();
                    break;

                case 3:
                    System.out.println("\n**** grille sauvegardée ... \n");
                    this.save("save.txt", grille);
                    break;

                case 4:
                    System.out.println("\n**** Quitter le jeu ... \n");
                    System.exit(1);
            }
            grille.afficheGrille(false);
        }
    }

    public static void main(String[] args) throws Exception{
      System.out.println("\n\n====================== Bienvenue dans le jeu du démineur ======================\n\n");
      Demineur demineur = new Demineur();
      demineur.jouer();
    }

}
