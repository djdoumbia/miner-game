package poo.tp.premierspas;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.FlowLayout;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.plaf.nimbus.NimbusLookAndFeel;


public class Frame extends JFrame{
    private static final long serialVersionUID = 1L;
    private JFrame frame;
    private JButton[][] buttons;
    private final int ligne ;
    private final int colonne;


    public Frame(String titre, Grille grille) throws Exception{
        this.ligne = grille.getNbLigne();
        this.colonne = grille.getNbColonne();
        this.setTitle(titre);
        this.setSize(600, 400);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// pour areter l'execution de la fenetre quant on quite
        this.setResizable(false);
        this.setLocationRelativeTo(null);// placer la fenetre au mileux de l'ecrant
        buttons = new JButton[ligne][colonne];
        JPanel panel  = new JPanel(new GridLayout(ligne, colonne));
        for(int i = 0; i < ligne; i++){
            for(int j = 0; j < colonne; j++){
                buttons[i][j] = new JButton();
                buttons[i][j].addActionListener(new ActionListener(){
                    @Override
                    public void actionPerformed(ActionEvent e){
                        // Code à exécuter lorsque l'utilisateur clique sur un bouton
                        //System.out.println("Bouton cliqué !");
                    }
                });
                panel.add(buttons[i][j]);
            }
        }
        UIManager.setLookAndFeel(new NimbusLookAndFeel());// juste pour avoir un look plus jolie
        frame = new JFrame("Jeu demineur"); // instancier la fenêtre
        frame.add(panel); // ajouter le panneau à la fenêtre
        frame.pack(); // redimensionner la fenêtre pour qu'elle s'adapte à son contenu
        frame.setLocationRelativeTo(null); // Centre la fenêtre au milieu de l'écran
        frame.setVisible(true);
    }
}