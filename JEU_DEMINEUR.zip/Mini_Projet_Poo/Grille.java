package poo.tp.premierspas;
import java.util.*;

public class Grille {
    private final int nbLigne;
    private final int nbColonne;
    private final int nbCases;
    private final int pourcentageMinesPlacees;
    private final Case[][] grille;
    
    public Grille(int nbLigne, int nbColonne, int pourcentageMinesPlacees){
        this.nbLigne = nbLigne;
        this.nbColonne = nbColonne;
        this.nbCases =  this.nbLigne * this.nbColonne;
        this.pourcentageMinesPlacees = pourcentageMinesPlacees;
        this.grille = new Case[nbLigne][nbColonne];
    }

    // retourne une case dans la grille
     public Case getCase(int ligne, int colonne){
      return grille[ligne][colonne];
    }

    public int getNbLigne(){
        return this.nbLigne;
    }

    public int getNbColonne(){
        return this.nbColonne;
    }
    public int getPourcentageMinesPlacees(){
        return this.pourcentageMinesPlacees;
    }


   /***************************************************************************************************
    * initialiseGrille      Elle initialise la grille du jeu en créant des objets Case pour chaque    *
    *                        cellule et en configurant les voisins pour chaque cellule                *
    *                                                                                                 *
    **************************************************************************************************/
    public void initialiseGrille(){
        for(int i = 0; i < this.nbLigne; i++) {
            for (int j = 0; j < this.nbColonne; j++) {
                grille[i][j] = new Case(i, j);
            }
        }
        for(int i = 0; i < this.nbLigne; i++){
            for(int j = 0; j < this.nbColonne; j++){
                if(i > 0) {
                    grille[i][j].setVoisin(Direction.Nord, grille[i - 1][j]);
                    if(j > 0){
                        grille[i][j].setVoisin(Direction.NordOuest, grille[i - 1][j - 1]);
                    }
                    if(j < this.nbColonne - 1){
                        grille[i][j].setVoisin(Direction.NordEst, grille[i - 1][j + 1]);
                    }
                }
                if(j > 0) {
                    grille[i][j].setVoisin(Direction.Ouest, grille[i][j - 1]);
                }
                if(j < this.nbColonne - 1) {
                    grille[i][j].setVoisin(Direction.Est, grille[i][j + 1]);
                }
                if(i < this.nbLigne - 1) {
                    grille[i][j].setVoisin(Direction.Sud, grille[i + 1][j]);
                    if(j > 0) {
                        grille[i][j].setVoisin(Direction.SudOuest, grille[i + 1][j - 1]);
                    }
                    if(j < this.nbColonne - 1) {
                        grille[i][j].setVoisin(Direction.SudEst, grille[i + 1][j + 1]);
                    }
                }
                if(i == 0){
                    if(j == 0){
                        //on recupere est sud et sudEst
                        grille[i][j].setVoisin(Direction.Est, grille[i][j + 1]);
                        grille[i][j].setVoisin(Direction.Sud, grille[i + 1][j]);
                        grille[i][j].setVoisin(Direction.SudEst, grille[i + 1][j + 1]);
                    }
                    else if(j == this.nbColonne - 1){
                        //on recupere ouest sud et sudOuest
                        grille[i][j].setVoisin(Direction.Ouest, grille[i][j - 1]);
                        grille[i][j].setVoisin(Direction.Sud, grille[i + 1][j]);
                        grille[i][j].setVoisin(Direction.SudOuest, grille[i + 1][j - 1]);
                    }
                    else{
                        //on recupere ouest sud et est
                        grille[i][j].setVoisin(Direction.Ouest, grille[i][j - 1]);
                        grille[i][j].setVoisin(Direction.Sud, grille[i + 1][j]);
                        grille[i][j].setVoisin(Direction.Est, grille[i][j + 1]);
                    }                  
                }
                if (i == this.nbLigne - 1){
                    if(j == 0){
                        //on recupere nord  est et nordEst
                        grille[i][j].setVoisin(Direction.Nord, grille[i - 1][j]);
                        grille[i][j].setVoisin(Direction.Est, grille[i][j + 1]);
                        grille[i][j].setVoisin(Direction.NordEst, grille[i - 1][j + 1]);
                    }
                    else if(j == this.nbColonne - 1){
                        //on recupere ouest Nord et nordOuest
                        grille[i][j].setVoisin(Direction.Ouest, grille[i][j - 1]);
                        grille[i][j].setVoisin(Direction.Nord, grille[i - 1][j]);
                        grille[i][j].setVoisin(Direction.NordOuest, grille[i - 1][j - 1]);
                    }
                    else{
                        //on recupere ouest nord et est
                        grille[i][j].setVoisin(Direction.Nord, grille[i - 1][j]);
                        grille[i][j].setVoisin(Direction.Ouest, grille[i][j - 1]);
                        grille[i][j].setVoisin(Direction.Est, grille[i][j + 1]);
                    }  
                }
                if((j == 0) && (i > 0) && (i < this.nbLigne - 1)){
                    // on recupere nord, sud et est
                    grille[i][j].setVoisin(Direction.Nord, grille[i - 1][j]);
                    grille[i][j].setVoisin(Direction.Sud, grille[i + 1][j]);
                    grille[i][j].setVoisin(Direction.Est, grille[i][j + 1]);
                }
                if ((j == this.nbColonne - 1) && (i > 0) && (i < this.nbLigne - 1)){
                    // on recupere nord, sud et ouest
                    grille[i][j].setVoisin(Direction.Nord, grille[i - 1][j]);
                    grille[i][j].setVoisin(Direction.Sud, grille[i + 1][j]);
                    grille[i][j].setVoisin(Direction.Ouest, grille[i][j - 1]);
                }
            }
        }
    }
   /***************************************************************************************************
    * placeMine         Fonction qui  place un certain nombre de mines aléatoirement dans une         *
    *                   grille de jeu. Le nombre de mines à placer dépend du pourcentage de mines     *
    *                   à placer et du nombre de cases dans la grille                                 *
    *                                                                                                 *
    **************************************************************************************************/
    public  void  placeMine(){
        Random random = new Random();
        int nbMinesPlacees = (this.nbCases * this.pourcentageMinesPlacees) / 100 ;
        int compteurMines = 0 ;
        while (compteurMines < nbMinesPlacees){
            int indice = random.nextInt(this.nbCases);
            int ligne = indice / this.nbColonne;
            int colonne = indice % this.nbColonne;
            if (!grille[ligne][colonne].estMinee()){
                grille[ligne][colonne].setEstMine(true);
                grille[ligne][colonne].setValeur(-1);
                compteurMines++;
            }
        }
    }

   /**************************************************************************************************
    * afficheGrille      Fonction qui affiche la grille du jeu dans la console avec des symboles     *
    *                    différents pour chaque case. Elle utilise des codes de couleurs pour        *
    *                    différencier les différents types de cases.                                 *
    *                    Les symboles utilisés incluent MINE_SYMBOL pour les cases minées,           *
    *                    COVERED_SYMBOL pour les cases non découvertes et FLAG_SYMBOL                *
    *                    pour les cases marquées.                                                    *
    *                                                                                                *
    *                                                                                                *
    * En entrée:       Elle prend un argument booléen "isInitial" qui indique si la grille doit être *
    *                  affichée dans son état initial ou dans son état actuel(etat enregistré ).     *
    **************************************************************************************************/
    public void afficheGrille(boolean isInitial) {
        final char MINE_SYMBOL = '\u25CF';
        final char COVERED_SYMBOL = '\u25A1';
        final char FLAG_SYMBOL = '\u2691';

        System.out.print(" ");
        System.out.println();

        for (int i = 0; i < this.nbLigne; i++) {
            for (int j = 0; j < this.nbColonne; j++) {
                if (isInitial) {
                    if (grille[i][j].estMinee()) {
                        System.out.print("| \u001B[31m" + MINE_SYMBOL + "\u001B[0m "); // rouge
                    } else {
                        System.out.print("| \u001B[34m" + getCase(i, j).getValeur() + "\u001B[0m "); // bleu
                    }
                } else {
                    if (grille[i][j].estDecouverte()) {
                        System.out.print("| \u001B[34m" + grille[i][j].getNbMinesVoisines() + "\u001B[0m ");
                    }
                    else if (grille[i][j].estMarquee()){
                        System.out.print("| \u001B[34m" + FLAG_SYMBOL + "\u001B[0m ");
                    }
                    else {
                        System.out.print("| * ");
                    }
                }
            }
            System.out.println("|");
        }
    }

}



  








