package poo.tp.premierspas;
import java.util.EnumMap;

public class Case {
    private final int ligne;
    private final int colonne;
    private int nbMinesVoisines;
    private int valeur;
    private boolean caseEstMinee;
    private boolean caseEstMarquee;
    private boolean caseEstDecouverte;
    private final EnumMap<Direction, Case> voisins;

    public Case(int ligne, int colonne) {
        this.ligne = ligne;
        this.colonne = colonne;
        this.nbMinesVoisines = 0;
        this.valeur = 0;
        this.caseEstMinee = false;
        this.caseEstDecouverte = false;
        this.caseEstMarquee = false;
        this.voisins = new EnumMap<>(Direction.class);
    }

    public int getValeur() {
        return this.valeur;
    }

    public void setValeur(int valeur) {
        this.valeur = valeur;
    }

    public int getNbMinesVoisines() {
        return this.nbMinesVoisines;
    }

    public boolean estMinee() {
        return this.caseEstMinee;
    }

    public boolean estMarquee() {
        return this.caseEstMarquee;
    }

    public boolean estDecouverte() {
        return this.caseEstDecouverte;
    }

    public void setEstMine(boolean caseEstMinee) {
        this.caseEstMinee = caseEstMinee;
    }

    public void setEstDecouverte(boolean caseEstDecouverte) {
        this.caseEstDecouverte = caseEstDecouverte;
    }

    public void setEstMarquee(boolean caseEstMarquee) {
        this.caseEstMarquee = caseEstMarquee;
    }

    /*************************************************************************************************
    * setVoisin             Fonction qui permet d'ajouter une case voisine à une case qui existe     *
    *                       et l'ajoute aussi au dictionnaire des voisins de la case                 *                                                          *
    *                                                                                                *
    **************************************************************************************************/
    public void setVoisin(Direction direction, Case caseVoisin) {
        this.voisins.put(direction, caseVoisin);
    }

    /*************************************************************************************************
    * marquerCase           Fonction qui permet de marquer une case non decouverte et non            *
    *                        marquée.                                                                *
    *                                                                                                *
    **************************************************************************************************/
    public void marquerCase(){
        if(!this.caseEstDecouverte && !this.caseEstMarquee) {
            this.caseEstMarquee = true;
        }
        else {
            System.out.println("!!! On ne peut pas marquer une case découverte ou déja marquée !!!");
        }
    }

    /*************************************************************************************************
    * uncover               Fonction qui permet de decouvrir une case qui n'est ni marquée,          *
    *                        ni decouverte et mettre à jour sa valeur en fonction de ces cases       *
    *                        voisines.Elle fait aussi un appel récrussive de la methode "uncover"    *
    *                        sur les cases voisines non decouverte                                   *
    *                                                                                                *
    * En entrée:             un boolean chargementGrille qui est "true "  si on veut recharger       *
    *                         une grille précedente sinon  "false" pour une nouvelle grille          *
    **************************************************************************************************/
    public void uncover(boolean chargementGrille) {
        if (!this.caseEstMarquee && !this.caseEstDecouverte) {
            this.caseEstDecouverte = true;
            for (Direction direction : Direction.values()) {
                boolean existeVoisin = this.voisins.containsKey(direction);
                if (existeVoisin) {
                    Case caseVoisine = this.voisins.get(direction);
                    if (caseVoisine != null) {
                        if (caseVoisine.estMinee() && caseVoisine.getValeur() == -1) {
                            this.nbMinesVoisines += 1;
                        }
                    }
                }
            }
            if (this.nbMinesVoisines != 0) {
                this.valeur = this.nbMinesVoisines;
            } else {
                for (Direction direction : Direction.values()) {
                    boolean existeVoisin = this.voisins.containsKey(direction);
                    if (existeVoisin) {
                        Case caseVoisine = this.voisins.get(direction);
                        if (!caseVoisine.estDecouverte()) {
                            caseVoisine.uncover(false);
                        }
                    }
                }
            }
        }
        else {
            if (!chargementGrille){
                System.out.println("!!! On ne peut pas découvrir une case découverte ou marquée !!!");
            }
        }
    }
}

